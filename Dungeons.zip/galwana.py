def galwana(x, sx):
    return((x+9) % sx-9)
